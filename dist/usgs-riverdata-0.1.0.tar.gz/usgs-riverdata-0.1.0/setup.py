# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['usgs_riverdata']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'usgs-riverdata',
    'version': '0.1.0',
    'description': 'Pulls data from the USGS Water Data service',
    'long_description': '',
    'author': 'William French',
    'author_email': 'wdfrench13@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/wdfrench13/usgs-waterdata',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
